package code;

public class Border {
  // here border class is defined with length and width as parameters.
  int length = 1000;    // length is assumed to be 1000 initially, but it doesn't matter though.
  int width;      // width will be accessed by Main function later on.
}
