package generic;

public interface Element {
	// handles the event by calling event object in handleEvent method.
	void handleEvent(Event event);

}
